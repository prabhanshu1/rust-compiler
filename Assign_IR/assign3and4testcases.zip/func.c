int foo ()
{
    int i = 1;
    return 0;
}

int main(){
    int i = foo();
    return 0;
}
